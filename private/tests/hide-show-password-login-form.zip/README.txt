A Pen created at CodePen.io. You can find this one at https://codepen.io/geoffreyrose/pen/HKDkB.

 An example of A Hide/Show password toggle